
//helper functions



//creare layout

class Notiuni {
    constructor(settings) {
        this.promises = []
        this.layout = ''
        this.menu_arr = settings.menu_arr

        this.incarcaLayout(settings.layoutFile)

        this.test_this()//trebuie sa functioneze dupa ce toate promisiunile s-au terminat

    }


    incarcaLayout = (caleFisier) => {
        let loadFile = async (caleFisier) => {
            let response = await fetch(caleFisier)
            this.layout = await response.text()
            // console.log(layout)

        }

        let promise_layout = loadFile(caleFisier) // la momentul executarii din constructor fisierul inca nu a fost incarcat
        this.promises.push(promise_layout)//promisiunea pentru loadfile se incarca in lista de promisiuni care este creata in constructor
    }


    test_this() {
        Promise.all(this.promises).then(() => {
            console.log(this.menu_arr)
            console.log(this.layout)
        })

    }

}


let settings = {
    menu_arr: ['notiuni win', 'notiuni excel'],
    layoutFile: './layout.html'
}

let prj1 = new Notiuni(settings)

export default prj1


// let func = (a) => a + a
// let obj = { test: "aaaa" }
// let exp = {
//     func, obj, x
// }