//console.log(table_parse.outerHTML) // pentru conversie element in text
//main.append(table_parse)


//v2
// let elem = document.createElement('div') // pentru conversie text in element html
// elem.innerHTML = data
// let table = elem.querySelector('table')
//main.append(table)
