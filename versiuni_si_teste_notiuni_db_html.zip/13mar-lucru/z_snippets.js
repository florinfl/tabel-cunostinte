//console.log(table_parse.outerHTML) // pentru conversie element in text
//main.append(table_parse)


//v2
// let elem = document.createElement('div') // pentru conversie text in element html
// elem.innerHTML = data
// let table = elem.querySelector('table')
//main.append(table)




// let loadFile = (caleFisier) => {

//     return fetch(caleFisier)
//         .then(res => res.text())
//         .then(layout => {
//             //console.log(layout)
//             this.layout = layout
//         })



// }

// let loadFile = async (caleFisier) => {
//     let response = await fetch(caleFisier)
//     this.layout = await response.text()
//     // console.log(layout)

// }