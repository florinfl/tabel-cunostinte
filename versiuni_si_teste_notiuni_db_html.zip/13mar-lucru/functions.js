import helper from './helper.js'

let { incarcaFisier, proceseazaMenu } = helper

class Notiuni {
    constructor(settings) {
        this.init(settings)
        // ❌ Mutat apelul executaDupaPromisiuni din constructor în init, deci îl scoatem de aici
        // this.executaDupaPromisiuni()
    }

    init = (settings) => {
        this.layoutElement = document.querySelector('#layout')
        this.menuElement = null

        this.resources = {
            layout: "layout resource",
            menu_json: [],
            menu_text: 'menu text',
            promises: []
        }

        // 🔹 Încarcă fișiere și pune promisiunile în array
        incarcaFisier(settings.layoutFile, 'text', this.resources, "layout")
        incarcaFisier(settings.menuFile, 'json', this.resources, "menu_json")

        // 🔥 Apel executaDupaPromisiuni după ce am populat array-ul de promisiuni
        this.executaDupaPromisiuni()
    }

    afiseazaLayout = () => {
        this.layoutElement.innerHTML = this.resources.layout
    }

    afiseazaMenu = () => {
        if (!this.menuElement) {
            console.error("menuElement nu a fost găsit în layout")
            return
        }
        this.menuElement.innerHTML = this.resources.menu_text
    }

    executaDupaPromisiuni() {
        Promise.all(this.resources.promises).then(() => {
            console.log("MENU JSON:", this.resources.menu_json)

            this.resources.menu_text = proceseazaMenu(this.resources.menu_json)
            this.afiseazaLayout()

            // MenuElement trebuie căutat după ce layout-ul a fost inserat în DOM
            this.menuElement = document.querySelector('.nav-center .nav-links')
            this.afiseazaMenu()
        }).catch(err => {
            console.error("Eroare la încărcarea fișierelor:", err)
        })
    }
}

let settings = {
    layoutFile: './layout.html',
    menuFile: './menu.json'
}

let prj1 = new Notiuni(settings)

export default prj1