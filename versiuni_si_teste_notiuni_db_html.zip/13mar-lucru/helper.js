let incarcaFisier = (caleFisier, tip_fisier, resurse, camp) => {
    //se incarca in resurse in campul camp, trebuie lasat un obiect ca parametru altfel nu se face transferul prin referinta

    let loadFile = (caleFisier) => {

        return new Promise((resolve) => {

            return fetch(caleFisier)
                .then(res => {
                    if (res.ok) {
                        if (tip_fisier === 'text')
                            return res.text()
                        else if (tip_fisier === 'json')
                            return res.json()
                    }
                    throw new Error('Something wrong')
                })
                .then(resolve)
                .catch(err => { console.log(err) })

        })

    }


    let prom = loadFile(caleFisier).then(continut => {
        //console.log(continut)
        resurse[camp] = continut

    }).catch((err) => {
        console.log(err)
    })

    // la momentul executarii din constructor fisierul inca nu a fost incarcat

    resurse.promises.push(prom)//promisiunea pentru loadfile se incarca in lista de promisiuni care este creata in constructor

}

let proceseazaMenu = (menu_json) => {
    //converteste in li-uri cu link-uri deci trebuie inserat intr-un <ul> la destinatie
    //tot aici se adauga parametri sau query pe url sau id-uri in link-uri sau li-uri
    let m = menu_json.map(el => {


        return `<li><a href="${el.url}">${el.optiune}</a></li>`


    }).join("")
    return m
}
let functiiHelper = {}

functiiHelper.incarcaFisier = incarcaFisier
functiiHelper.proceseazaMenu = proceseazaMenu

export default functiiHelper