let menu = { name: "menu" }
let table = { name: "table" }
let side_bar = { name: "side_bar" }


let mainApp = {
    nume: "mainApp",
    menu,
    table,
    side_bar,
    action(entryPoint) {
        console.log(`va incarca ${menu.name},${table.name},${side_bar.name}  in :${entryPoint}`)
    }
}


export { mainApp }