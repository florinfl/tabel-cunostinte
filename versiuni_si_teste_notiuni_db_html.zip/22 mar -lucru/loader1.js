import { mainApp } from "./main.js"

let loader1 = {
    nume: "loader1",
    action(entryPoint) {
        console.log(`va incarca modulul principal in :${entryPoint}`)
        mainApp.action()
    }
}


export { loader1 }