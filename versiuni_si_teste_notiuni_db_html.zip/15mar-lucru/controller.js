
import Layout from './h_layout.js'
import Menu from './h_menu.js'
import Table_db from './h_table_db.js'
import helper from './helper.js'

let { proceseazaMenu } = helper

class NotiuniController {
    constructor(settings) {

        this.init(settings)
        //  this.executaDupaPromisiuni()//trebuie sa functioneze dupa ce toate promisiunile s-au terminat

    }


    init = (settings) => {
        this.selectorMenu = '.nav-center .nav-links'
        this.selectorLayout = '#layout'
        this.selectorTable = 'main'

        this.layout = new Layout(settings.layoutFile)
        // console.log(this.layout.info)

        this.menu = new Menu(settings.menuFile)
        // console.log(this.menu.info)

        this.table_db = new Table_db(settings.table_db_file)
        // console.log(this.table_db.info)

        this.layoutElement = document.querySelector(this.selectorLayout)

        this.adaugaLayout(this.layoutElement).then(componente => {
            this.adaugaMenu(componente.destinatieMenu)
            this.adaugaTabel(componente.destinatieTabel)

        })

    }

    adaugaLayout = (destinatieLayout) => {
        return new Promise((resolve) => {
            this.layout.getLayout().then(layoutText => {

                destinatieLayout.innerHTML = layoutText
                let componente = {}
                componente.destinatieMenu = destinatieLayout.querySelector(this.selectorMenu)
                componente.destinatieTabel = destinatieLayout.querySelector(this.selectorTable)
                //console.log(destinatieMenu)
                resolve(componente)
            })
        })
    }

    adaugaMenu = (destinatieMenu) => {
        this.menu.getMenu().then(dataMenu => {
            destinatieMenu.innerHTML = proceseazaMenu(dataMenu)
        })
    }

    adaugaTabel = (destinatieTabel) => {

        this.table_db.getTable().then(dataTable => {
            destinatieTabel.innerHTML = dataTable
        })
    }
}


let settings = {
    layoutFile: './layout.html',
    menuFile: './menu.json',
    table_db_file: './index_db2.html'
}

let prj1 = new NotiuniController(settings)

export default prj1

