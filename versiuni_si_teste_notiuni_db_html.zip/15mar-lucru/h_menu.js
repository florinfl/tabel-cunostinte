import helper from './helper.js'
let { loadFile } = helper


class Menu {
    constructor(menuFile) {
        this.menuFile = menuFile

    }

    get info() {
        return "test menu"
    }

    getMenu = () => {

        return loadFile(this.menuFile, 'json')

    }

}


export default Menu