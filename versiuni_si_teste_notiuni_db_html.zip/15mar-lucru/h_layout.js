import helper from './helper.js'
let { loadFile } = helper


class Layout {
    constructor(layoutFile) {
        this.layoutFile = layoutFile
    }

    get info() {
        return "test layout"
    }

    getLayout = () => {

        return loadFile(this.layoutFile, 'text')

    }

}


export default Layout