

let loadFile = (caleFisier, tip_fisier) => {

    return new Promise((resolve) => {

        return fetch(caleFisier)
            .then(res => {
                if (res.ok) {
                    if (tip_fisier === 'text')
                        return res.text()
                    else if (tip_fisier === 'json')
                        return res.json()
                }
                throw new Error('Something wrong')
            })
            .then(resolve)
            .catch(err => { console.log(err) })

    })

}




let proceseazaMenu = (menu_json) => {
    //converteste in li-uri cu link-uri deci trebuie inserat intr-un <ul> la destinatie
    //tot aici se adauga parametri sau query pe url sau id-uri in link-uri sau li-uri
    let m = menu_json.map(el => {


        return `<li><a href="${el.url}">${el.optiune}</a></li>`


    }).join("")
    return m
}
let functiiHelper = {}

functiiHelper.loadFile = loadFile
functiiHelper.proceseazaMenu = proceseazaMenu

export default functiiHelper