import helper from './helper.js'
let { loadFile } = helper


class Table_db {
    constructor(table_db_file) {
        this.table_db_file = table_db_file

    }

    get info() {
        return "test db"
    }

    getTable = () => {

        return loadFile(this.table_db_file, 'text')

    }

}


export default Table_db